<?php // nav.php
?>
<div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px;  background-color:#eee; padding:8px 16px; border-radius:4px;">
    <a href="/assessment_beginner/index.php">Dashboard</a>
    <a href="/assessment_beginner/pages/clients_list.php">Clients</a>
    <a href="/assessment_beginner/pages/services_list.php">Services</a>
    <a href="/assessment_beginner/pages/bookings_list.php">Bookings</a>
    <a href="/assessment_beginner/pages/tools_list_assign.php">Tools</a>
    <a href="/assessment_beginner/pages/payments_list.php">Payments</a>
</div>
<hr>